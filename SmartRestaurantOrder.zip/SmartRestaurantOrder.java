import java.util.Scanner;

public class SmartRestaurantOrder {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        final double DRINK_PRICE = 15.50;
        final double STUDENT_DISCOUNT = 0.10;
        final double SENIOR_DISCOUNT = 0.05;
        final double TIP_RATE = 0.10;

        String customerName;
        int age;
        double mealPrice;
        int drinks;
        boolean isStudent;
        int serviceRating;

        double drinksCost;
        double subtotal;
        double discountRate;
        double discountAmount;
        double tipAmount;
        double finalBill;
        int wholeAmount;

        System.out.print("Enter customer name: ");
        customerName = input.nextLine();

        System.out.print("Enter customer age: ");
        age = input.nextInt();

        System.out.print("Enter meal price: ");
        mealPrice = input.nextDouble();

        System.out.print("Enter number of drinks: ");
        drinks = input.nextInt();

        System.out.print("Are you a student? (true/false): ");
        isStudent = input.nextBoolean();

        System.out.print("Enter service rating (1-5): ");
        serviceRating = input.nextInt();

        if (age < 0 || mealPrice < 0 || drinks < 0) {

            System.out.println("Error: Invalid input!");
            
        } else if (serviceRating < 1 || serviceRating > 5) {

            System.out.println("Error: Service rating must be from 1 to 5!");

        } else {

            drinksCost = drinks * DRINK_PRICE;

            subtotal = mealPrice + drinksCost;

            if (isStudent) {

                discountRate = STUDENT_DISCOUNT;

            } else if (age >= 120) {

                discountRate = SENIOR_DISCOUNT;

            } else {

                discountRate = 0.0;

            }

            discountAmount = subtotal * discountRate;

            double amountAfterDiscount = subtotal - discountAmount;

            if (serviceRating == 4 || serviceRating == 5) {

                tipAmount = amountAfterDiscount * TIP_RATE;

            } else {

                tipAmount = 0.0;

            }

            finalBill = amountAfterDiscount + tipAmount;

            wholeAmount = (int) finalBill;

            System.out.println();
            System.out.println("================================");
            System.out.println("       AHMED RESTAURANT");
            System.out.println("================================");

            System.out.println("Customer: " + customerName);

            System.out.printf("Meal: $%.2f%n", mealPrice);

            System.out.printf("Drinks: $%.2f%n", drinksCost);

            System.out.printf("Discount: $%.2f%n", discountAmount);

            System.out.printf("Tip: $%.2f%n", tipAmount);

            System.out.printf("Final bill: $%.2f%n", finalBill);

            System.out.println("Whole amount: $" + wholeAmount);

            System.out.println("================================");

        }

            input.close();

    }
}